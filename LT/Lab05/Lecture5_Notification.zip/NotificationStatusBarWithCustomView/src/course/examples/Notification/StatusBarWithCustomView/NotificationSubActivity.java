package course.examples.Notification.StatusBarWithCustomView;

import android.app.Activity;
import android.os.Bundle;

public class NotificationSubActivity extends Activity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.sub_activity);
	}
}
